#include <stm32f1xx.h>


int ClockInit(void);